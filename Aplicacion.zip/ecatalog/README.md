# Volkswagen E-catalog

Catálogo electrónico de coches de la marca Volkswagen - Audi España, S.A.

Autores
--------
- Carlos Escuín Blasco: Director del proyecto. 545003@unizar.es
- Marcos Canales Mayo: Gestor de configuraciones. 467716@unizar.es
- Alejandro Dieste Cortés: Gestor de desarrollo. 541892@unizar.es
- Christian García Artero: Gestor de planificación. 597578@unizar.es
- Íñigo Alonso Ruiz: Gestor de calidad. 665959@unizar.es
